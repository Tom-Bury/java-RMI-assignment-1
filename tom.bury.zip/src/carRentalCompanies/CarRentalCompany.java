package carRentalCompanies;

import rental.*;

import java.rmi.RemoteException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CarRentalCompany implements ICarRentalCompany {

    private static Logger logger = Logger.getLogger(CarRentalCompany.class.getName());

    private List<String> regions;
    private String name;
    private List<Car> cars;
    private Map<String,CarType> carTypes = new HashMap<String, CarType>();

    /***************
     * CONSTRUCTOR *
     ***************/

    public CarRentalCompany(String name, List<String> regions, List<Car> cars) {
        logger.log(Level.INFO, "<{0}> Car Rental Company {0} starting up...", name);
        setName(name);
        this.cars = cars;
        setRegions(regions);
        for(Car car:cars)
            carTypes.put(car.getType().getName(), car.getType());
        logger.log(Level.INFO, this.toString());
        System.out.println("\n");
    }


    /********
     * NAME *
     ********/

    @Override
    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    /***********
     * Regions *
     **********/
    private void setRegions(List<String> regions) {
        this.regions = regions;
    }

    public List<String> getRegions() {
        return this.regions;
    }

    public boolean hasRegion(String region) {
        return this.regions.contains(region);
    }

    /*************
     * CAR TYPES *
     *************/

    public Collection<CarType> getAllCarTypes() {
        return carTypes.values();
    }

    public CarType getCarType(String carTypeName) {
        if(carTypes.containsKey(carTypeName))
            return carTypes.get(carTypeName);
        throw new IllegalArgumentException("<" + carTypeName + "> No car type of name " + carTypeName);
    }

    // mark
    public boolean isAvailable(String carTypeName, Date start, Date end) {
        logger.log(Level.INFO, "<{0}> Checking availability for car type {1}", new Object[]{name, carTypeName});
        if(carTypes.containsKey(carTypeName)) {
            return getAvailableCarTypes(start, end).contains(carTypes.get(carTypeName));
        } else {
            throw new IllegalArgumentException("<" + carTypeName + "> No car type of name " + carTypeName);
        }
    }

    public Set<CarType> getAvailableCarTypes(Date start, Date end) {
        Set<CarType> availableCarTypes = new HashSet<CarType>();
        for (Car car : cars) {
            if (car.isAvailable(start, end)) {
                availableCarTypes.add(car.getType());
            }
        }
        return availableCarTypes;
    }


    @Override
    public CarType getMostPopularCarType(int year) throws RemoteException {

        Map<CarType, Integer> carTypeReservations = new HashMap<>();

        for (Car c : this.cars) {
            CarType type = c.getType();
            int nbReservations = c.getNbReservationsInYear(year);
            int oldNbReservations = carTypeReservations.getOrDefault(type, 0);
            carTypeReservations.put(type, oldNbReservations + nbReservations);
        }

        CarType mostPopularType = null;
        int mostPopTypeNbReservations = 0;

        for (CarType type : carTypeReservations.keySet()) {
            int currNbRes = carTypeReservations.get(type);
            if (currNbRes > mostPopTypeNbReservations) {
                mostPopTypeNbReservations = currNbRes;
                mostPopularType = type;
            }
        }

        return mostPopularType;
    }

    @Override
    public Set<String> getAllCarTypesNames() {
        return this.carTypes.keySet();
    }

    /*********
     * CARS *
     *********/

    private Car getCar(int uid) {
        for (Car car : cars) {
            if (car.getId() == uid)
                return car;
        }
        throw new IllegalArgumentException("<" + name + "> No car with uid " + uid);
    }

    public List<Car> getAvailableCars(String carType, Date start, Date end) {
        List<Car> availableCars = new LinkedList<Car>();
        for (Car car : cars) {
            if (car.getType().getName().equals(carType) && car.isAvailable(start, end)) {
                availableCars.add(car);
            }
        }
        return availableCars;
    }

    /****************
     * RESERVATIONS *
     ****************/

    public Quote createQuote(ReservationConstraints constraints, String client)
            throws ReservationException {
        logger.log(Level.INFO, "<{0}> Creating tentative reservation for {1} with constraints {2}",
                new Object[]{name, client, constraints.toString()});
        //TODO: logger terug aanzetten en de sout verwijderen
//        System.out.println("    <"+name+"> Creating tentative reservation for "+client+" with constraints");
//        System.out.println(constraints.toString());


        if(!regions.contains(constraints.getRegion()) || !isAvailable(constraints.getCarType(), constraints.getStartDate(), constraints.getEndDate()))
            throw new ReservationException("<" + name
                    + "> No cars available to satisfy the given constraints.");

        CarType type = getCarType(constraints.getCarType());

        double price = calculateRentalPrice(type.getRentalPricePerDay(),constraints.getStartDate(), constraints.getEndDate());


        return new Quote(client, constraints.getStartDate(), constraints.getEndDate(), getName(), constraints.getCarType(), price);
    }

    // Implementation can be subject to different pricing strategies
    private double calculateRentalPrice(double rentalPricePerDay, Date start, Date end) {
        return rentalPricePerDay * Math.ceil((end.getTime() - start.getTime())
                / (1000 * 60 * 60 * 24D));
    }

    public synchronized Reservation confirmQuote(Quote quote) throws ReservationException {
        logger.log(Level.INFO, "<{0}> Reservation of {1}", new Object[]{name, quote.toString()});
        List<Car> availableCars = getAvailableCars(quote.getCarType(), quote.getStartDate(), quote.getEndDate());
        if(availableCars.isEmpty())
            throw new ReservationException("Reservation failed, all cars of type " + quote.getCarType()
                    + " are unavailable from " + quote.getStartDate() + " to " + quote.getEndDate());
        Car car = availableCars.get((int)(Math.random()*availableCars.size()));

        Reservation res = new Reservation(quote, car.getId());
        car.addReservation(res);
        return res;
    }

    @Override
    public synchronized void cancelReservation(Reservation res) {
        logger.log(Level.INFO, "<{0}> Cancelling reservation {1}", new Object[]{name, res.toString()});
        getCar(res.getCarId()).removeReservation(res);
    }


    public List<Reservation> getAllReservationsFrom(String carRenter) {
        List<Reservation> reservations = new ArrayList<>();

        for (Car car : this.cars) {
            List<Reservation> currCarReservations = car.getReservations(carRenter);
            reservations.addAll(currCarReservations);
        }

        return reservations;
    }

    public int getNbReservations(String carType) {
        int counter = 0;

        for (Car car : this.cars) {
            if (car.isType(carType)) {
                counter += car.getNbReservations();
            }
        }

        return counter;
    }


    @Override
    public Map<String, Integer> getAllCustomersAndReservationNumbers() throws RemoteException {
        Map<String, Integer> allCustomersAndReservationNbs = new HashMap<>();

        for (Car c : this.cars) {
            Map<String, Integer> currCarCustAndResvNbs = c.getAllCustomersAndReservationNbs();

            for (String currCust : currCarCustAndResvNbs.keySet()) {
                int currNbRes = currCarCustAndResvNbs.get(currCust);
                int oldNbRes = allCustomersAndReservationNbs.getOrDefault(currCust, 0);
                allCustomersAndReservationNbs.put(currCust, oldNbRes + currNbRes);
            }
        }

        return allCustomersAndReservationNbs;
    }

    /******************
     * STRING & UTILS *
     * ****************/

    @Override
    public String toString() {
        return String.format("<%s> CRC is active in regions %s and serving with %d car types", name, listToString(regions), carTypes.size());
    }

    private static String listToString(List<? extends Object> input) {
        StringBuilder out = new StringBuilder();
        for (int i=0; i < input.size(); i++) {
            if (i == input.size()-1) {
                out.append(input.get(i).toString());
            } else {
                out.append(input.get(i).toString()+", ");
            }
        }
        return out.toString();
    }

    private static String mapToString(Map<String, Integer> map) {
        StringBuilder builder = new StringBuilder();

        for (String key : map.keySet()) {
            builder.append(key);
            builder.append(" - ");
            builder.append(map.get(key));
            builder.append(" | ");
        }

        return builder.toString();
    }
}
